<?php declare(strict_types=1);
/**
 *To help phpstan dealing with LogicException in Common\User\User.php
 */

define('GRAV_USER_INSTANCE', 'FLEX');
define('GRAV_REQUEST_TIME', microtime(true));
